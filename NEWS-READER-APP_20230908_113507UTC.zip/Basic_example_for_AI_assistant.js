intent(`(Read|Get) the news from $(item* (.*)) Category` , (p) =>{
    if(p.item.value){
        p.play( { command : `Voice News` , data : p.item.value});
        p.play({ command : `Fetching news on ${p.item.value} Category`});
    }
      else{
       p.play('Can not get the data');
       }
})